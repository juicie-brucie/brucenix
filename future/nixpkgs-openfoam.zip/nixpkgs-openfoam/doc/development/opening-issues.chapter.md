# Opening issues {#sec-opening-issues}

* Make sure you have a [GitHub account](https://github.com/signup/free)
* Make sure there is no open issue on the topic
* [Submit a new issue](https://github.com/NixOS/nixpkgs/issues/new/choose) by choosing the kind of topic and fill out the template

<!-- In the future this section could also include more detailed information on the issue templates -->
