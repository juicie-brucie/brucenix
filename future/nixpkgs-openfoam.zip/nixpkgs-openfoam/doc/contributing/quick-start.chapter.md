# Quick Start to Adding a Package {#chap-quick-start}

This section has been moved to [pkgs/README.md](https://github.com/NixOS/nixpkgs/blob/master/pkgs/README.md).
