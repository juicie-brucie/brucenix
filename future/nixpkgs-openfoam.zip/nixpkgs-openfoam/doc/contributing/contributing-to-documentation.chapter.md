# Contributing to Nixpkgs documentation {#chap-contributing}

This section has been moved to [doc/README.md](https://github.com/NixOS/nixpkgs/blob/master/doc/README.md).

## devmode {#sec-contributing-devmode}

This section has been moved to [doc/README.md](https://github.com/NixOS/nixpkgs/blob/master/doc/README.md).

## Syntax {#sec-contributing-markup}

This section has been moved to [doc/README.md](https://github.com/NixOS/nixpkgs/blob/master/doc/README.md).
