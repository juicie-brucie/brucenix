# bmake {#bmake-hook}

[bmake](https://www.crufty.net/help/sjg/bmake.html) is the portable variant of
NetBSD make utility.

In Nixpkgs, `bmake` comes with a hook that overrides the default build, check,
install and dist phases.
