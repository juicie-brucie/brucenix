# Release Notes {#chap-release-notes}

This section lists the release notes for each stable version of Nixpkgs and current unstable revision.

```{=include=} sections
rl-2505.section.md
```
