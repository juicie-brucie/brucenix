local role_post
getHostRole
export NIX_LDFLAGS${role_post}+=" -L@out@/lib"
unset -v role_post
