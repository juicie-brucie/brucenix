#include_next <sys/types.h>

// for makedev, major, minor
#include <sys/sysmacros.h>

// For htonl, htons, etc.
#include <arpa/inet.h>

// for uint32_t etc.
#include <stdint.h>
