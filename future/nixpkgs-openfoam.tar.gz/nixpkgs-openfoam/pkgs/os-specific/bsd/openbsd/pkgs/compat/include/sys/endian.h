// Seems to be the only header for htonl
#include <netinet/in.h>
