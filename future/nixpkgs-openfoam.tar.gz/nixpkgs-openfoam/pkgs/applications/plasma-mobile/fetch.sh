WGET_ARGS=( https://download.kde.org/stable/plasma-mobile/23.01.0/ -A '*.tar.xz' )
