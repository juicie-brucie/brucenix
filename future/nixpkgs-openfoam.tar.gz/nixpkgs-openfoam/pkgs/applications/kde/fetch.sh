WGET_ARGS=( https://download.kde.org/stable/release-service/23.08.5/src -A '*.tar.xz' )
