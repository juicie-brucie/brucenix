WGET_ARGS=( https://download.kde.org/stable/maui/ -A '*.tar.xz' )
