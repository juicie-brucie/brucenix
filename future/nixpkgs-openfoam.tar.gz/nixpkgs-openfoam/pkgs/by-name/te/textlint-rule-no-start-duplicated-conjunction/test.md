But, A is ~.
So, A is ~.
But, A is ~.
