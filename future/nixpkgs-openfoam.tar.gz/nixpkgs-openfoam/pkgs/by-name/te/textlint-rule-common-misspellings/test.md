`textlint-rule-common-misspellings` is an old and mature libary.
