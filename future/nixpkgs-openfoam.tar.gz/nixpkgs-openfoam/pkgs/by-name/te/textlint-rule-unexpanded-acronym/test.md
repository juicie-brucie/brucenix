Passing an expression `expr` that evaluates to a store path to any built-in function which reads from the filesystem constitutes IFD.
