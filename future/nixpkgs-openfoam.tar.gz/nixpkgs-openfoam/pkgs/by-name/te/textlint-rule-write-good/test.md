So the cat was stolen.
