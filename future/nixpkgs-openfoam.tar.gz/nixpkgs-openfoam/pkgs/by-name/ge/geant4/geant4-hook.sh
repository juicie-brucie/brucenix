source @out@/bin/geant4.sh
