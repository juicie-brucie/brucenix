## services\.frobnicator\.types\.\<name>\.enable

Whether to enable the frobnication of this (` <name> `) type\.



*Type:*
boolean

*Declared by:*
 - [\<nixpkgs/nixos/modules/services/frobnicator\.nix>](https://github.com/NixOS/nixpkgs/blob/master/nixos/modules/services/frobnicator.nix)


