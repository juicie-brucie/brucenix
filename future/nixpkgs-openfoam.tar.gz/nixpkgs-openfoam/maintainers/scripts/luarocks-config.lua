
-- default of luarocks listed at src/luarocks/core/cfg.lua
-- keep this list synced with pkgs/build-support/fetchurl/mirrors.nix
rocks_servers = {
	"https://luarocks.org",
	"https://raw.githubusercontent.com/rocks-moonscript-org/moonrocks-mirror/master/"
}
version_check_on_fail = false
